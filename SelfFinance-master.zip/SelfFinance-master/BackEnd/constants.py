SOURCE = "https://www.alphavantage.co/documentation/" # API source
API_KEY = "CRU63X7J4COJ46F2" # api key for alpha vantage
